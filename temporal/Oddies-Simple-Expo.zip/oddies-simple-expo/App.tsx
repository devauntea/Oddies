import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AccessibilityInfo, AppState, Pressable, SafeAreaView, ScrollView, StyleSheet, Switch, Text, View, useWindowDimensions } from 'react-native';
import * as Speech from 'expo-speech';
import { OddiesCharacter } from './src/OddiesCharacter';
import { HELLO_DURATION, Mode } from './src/motion';

export default function App() {
  const [mode, setMode] = useState<Mode>('idle');
  const [speaking, setSpeaking] = useState(false);
  const [gestureId, setGestureId] = useState(0);
  const [voice, setVoice] = useState(true);
  const [active, setActive] = useState(AppState.currentState === 'active');
  const [reducedMotion, setReducedMotion] = useState(false);
  const [status, setStatus] = useState('Idle · gentle breathing');
  const request = useRef(0);
  const mounted = useRef(true);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);
  const { width } = useWindowDimensions();

  const clearTimers = () => { timers.current.forEach(clearTimeout); timers.current = []; };
  const stop = useCallback(() => {
    request.current += 1;
    clearTimers();
    setSpeaking(false);
    setMode('idle');
    setStatus('Idle · gentle breathing');
    void Speech.stop().catch(() => {});
  }, []);

  useEffect(() => {
    mounted.current = true;
    const appState = AppState.addEventListener('change', state => {
      setActive(state === 'active');
      if (state !== 'active') stop();
    });
    void AccessibilityInfo.isReduceMotionEnabled().then(enabled => {
      if (mounted.current) setReducedMotion(enabled);
    });
    const accessibility = AccessibilityInfo.addEventListener('reduceMotionChanged', setReducedMotion);
    return () => {
      mounted.current = false;
      request.current += 1;
      clearTimers();
      appState.remove();
      accessibility.remove();
      void Speech.stop().catch(() => {});
    };
  }, [stop]);

  const play = async (kind: 'talking' | 'hello') => {
    const id = ++request.current;
    clearTimers();
    setSpeaking(false);
    setMode('idle');
    try { await Speech.stop(); } catch { /* Continue with a fresh request. */ }
    const current = () => mounted.current && request.current === id;
    if (!current()) return;
    setMode(kind);
    setGestureId(id);
    let voiceDone = false;
    let waveDone = kind !== 'hello';
    const finish = () => {
      if (current() && voiceDone && waveDone) {
        setMode('idle');
        setStatus('Idle · gentle breathing');
      }
    };
    if (kind === 'hello') timers.current.push(setTimeout(() => { waveDone = true; finish(); }, HELLO_DURATION));
    const speechDone = () => {
      if (!current()) return;
      setSpeaking(false);
      voiceDone = true;
      finish();
    };
    if (!voice) {
      setStatus(kind === 'hello' ? 'Hello · silent animation test' : 'Talking · silent animation test');
      setSpeaking(true);
      timers.current.push(setTimeout(speechDone, kind === 'hello' ? 1750 : 4000));
      return;
    }
    setStatus('Waiting for device speech…');
    try {
      Speech.speak(kind === 'hello' ? "Hello! I'm your Oddie." : "Hi there. Let's explore what you could become.", {
        language: 'en-US', rate: 0.9,
        onStart: () => {
          if (current()) { setSpeaking(true); setStatus(kind === 'hello' ? 'Hello · one short wave' : 'Talking · device speech'); }
        },
        onDone: speechDone,
        onStopped: speechDone,
        onError: () => {
          speechDone();
          if (current()) setStatus('Speech unavailable. Turn Voice off for the silent test.');
        },
      });
    } catch {
      speechDone();
      if (current()) setStatus('Speech unavailable. Turn Voice off for the silent test.');
    }
  };

  return (
    <SafeAreaView style={styles.page}>
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={styles.eyebrow}>ODDIES · ANIMATION TEST</Text>
        <Text style={styles.title}>A little life.</Text>
        <Text style={styles.subtitle}>One character. Three simple movements.</Text>
        <View style={styles.stage}>
          <OddiesCharacter width={Math.min(width - 56, 310)} mode={mode} speaking={speaking} gestureId={gestureId} active={active} reducedMotion={reducedMotion} />
        </View>
        <Text style={styles.status} accessibilityLiveRegion="polite">{status}</Text>
        <View style={styles.buttons}>
          {(['idle', 'talking', 'hello'] as const).map(kind => (
            <Pressable key={kind} accessibilityRole="button" accessibilityState={{ selected: mode === kind }}
              onPress={() => kind === 'idle' ? stop() : void play(kind)}
              style={[styles.button, mode === kind && styles.selected]}>
              <Text style={[styles.buttonText, mode === kind && styles.selectedText]}>{kind === 'idle' ? 'Idle' : kind === 'talking' ? 'Talk' : 'Say hello'}</Text>
            </Pressable>
          ))}
        </View>
        <View style={styles.options}>
          <Text style={styles.optionLabel}>Voice</Text>
          <Switch accessibilityLabel="Enable device voice" value={voice} onValueChange={value => { stop(); setVoice(value); }} trackColor={{ true: '#815FD8' }} />
        </View>
        <Text style={styles.note}>Voice uses your device’s text-to-speech. Mouth movement is a simple visual rhythm.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  page: { flex: 1, backgroundColor: '#F7F4EE' },
  content: { alignItems: 'center', paddingHorizontal: 24, paddingTop: 28, paddingBottom: 32 },
  eyebrow: { color: '#817967', fontSize: 11, fontWeight: '700', letterSpacing: 2 },
  title: { color: '#302B40', fontSize: 34, fontWeight: '700', marginTop: 10 },
  subtitle: { color: '#817A89', fontSize: 14, marginTop: 8 },
  stage: { marginTop: 12, alignItems: 'center' },
  status: { minHeight: 22, color: '#74687D', fontSize: 12, textAlign: 'center', marginTop: 8 },
  buttons: { flexDirection: 'row', gap: 8, marginTop: 14 },
  button: { paddingVertical: 13, paddingHorizontal: 18, borderRadius: 20, backgroundColor: '#E9E3F0' },
  selected: { backgroundColor: '#7659C8' },
  buttonText: { color: '#5A4C70', fontSize: 13, fontWeight: '600' },
  selectedText: { color: '#FFFFFF' },
  options: { flexDirection: 'row', alignItems: 'center', gap: 12, marginTop: 15 },
  optionLabel: { color: '#74687D', fontSize: 13 },
  note: { maxWidth: 330, color: '#918996', fontSize: 11, lineHeight: 17, textAlign: 'center', marginTop: 8 },
});
