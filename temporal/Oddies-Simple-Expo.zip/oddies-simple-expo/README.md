# Oddies: simple Expo animation test

This kit uses the supplied girl character: cream sweater, navy trousers, glasses and long dark hair. It contains transparent PNG parts, a React Native component, three demo buttons, a self-contained browser preview and a silent rendered video.

The parts were regenerated from your references for separation, so small details differ from the original flattened image. The mouth overlays are editable SVG graphics exported to PNG. This is a simple layered character, with one movable arm; the other arm stays attached to the body.

## Try the animation

Open `preview.html` in a browser. Click **Idle**, **Talk**, or **Say hello**. The preview starts with voice off, so you can test motion immediately. Enable **Device voice** for your browser's speech synthesis. **Less motion** removes the breathing, tilt and arm rotation.

`test/animation-test.mp4` shows all three states without audio. `test/storyboard.png` shows the three key poses.

## Run it in Expo

Create a small TypeScript project:

```sh
npx create-expo-app@latest oddies-test --template blank-typescript
cd oddies-test
npx expo install expo-speech
```

Copy this kit's `App.tsx`, `src/` and `assets/` into the new project's root, replacing the generated `App.tsx`. Keep the generated Expo configuration, entry point and package files.

```sh
npx expo start
```

Open the project with Expo Go. The **Voice** switch is on in the native test. Turn it off to test the silent mouth movement without device speech. On a physical iPhone, turn silent mode off to hear `expo-speech`.

For an existing Expo Router app, keep your routes and import `OddiesCharacter` into a screen instead of replacing its entry point. Install `expo-speech` only if you want the included voice test.

## Use the component in your app

```tsx
import { OddiesCharacter } from './src/OddiesCharacter';

<OddiesCharacter
  width={300}
  mode="hello"
  gestureId={helloRequestId}
  speaking={isSpeaking}
  active={isScreenActive}
  reducedMotion={reduceMotionEnabled}
/>
```

`mode` is `idle`, `talking`, or `hello`. Set `speaking` from your audio player's start/end events, or use the included `expo-speech` example. Increment `gestureId` to replay hello even when the mode has not changed. A hello wave plays once and fades back to the resting arm after 2.36 seconds. Set `active` to false for an inactive screen so all motion stops and the mouth closes.

## The six PNGs

| File in `assets/` | Use |
|---|---|
| `body.png` | Sweater, legs, shoes and fixed arm |
| `head.png` | Face, glasses, hair and neck; blank mouth area |
| `arm-rest.png` | Movable arm in its resting pose |
| `arm-wave.png` | Same arm with an open palm for hello |
| `mouth-closed.png` | Closed smile |
| `mouth-open.png` | Open mouth |

All six have real alpha transparency. `atlas.png` is the original source sheet for the body, head and waving arm. The resting arm's orientation was corrected to match the viewer-right side of your reference; `arm-rest-source.png` is its updated source. The export tool uses that corrected source automatically. `mouth-closed.svg` and `mouth-open.svg` are editable source graphics for the mouth overlays.

## The three movements

| State | Movement | How it ends |
|---|---|---|
| Idle | 0.3% vertical breathing and a 0.65° head tilt over 3.6 seconds | Loops while active |
| Talking | Crossfade and scale between two mouth shapes | Mouth closes when speech stops |
| Hello | Fade to a raised arm, rotate gently around its shoulder, fade back | Plays once; returns to idle after speech and the wave finish |

The implementation uses built-in React Native `Animated` with the native driver for transforms and opacity. There is no per-frame React state update. `expo-speech` is the only additional runtime dependency. The demo cancels speech on backgrounding and ignores callbacks from replaced speech requests. The device's reduced-motion setting disables breathing and rotation; hello uses a static raised-arm pose with a short fade.

The mouth loop is a visual speaking rhythm, not phoneme-based lip sync. The resting and waving arms are two separate poses connected by a short crossfade. This keeps the test small and avoids a skeletal rig.

## Adjust the art and timing

Edit `src/layout.ts` for positions and joint pivots. Its coordinates use a 600 × 1010 canvas; `width` scales the whole composition. Edit `src/motion.ts` for amplitudes and timings. Native animation and the visual render use the same tracks and sine easing.

Mouth position follows the head wrapper, so it stays aligned when the head tilts. The body breathing pivot is at the feet; the head pivot is at the neck, and the waving arm pivots at the shoulder.

## Validation and limits

The delivered PNGs were checked for transparency. The assembled poses were visually inspected. Syntax/transpilation, bounded animation tracks, mouth closure, one-shot waving, reduced motion, stale speech callbacks and background cancellation were checked. App state and speech tests execute the actual `App.tsx` with mocked native APIs. Details are in `test/verification.json`.

No Expo device/emulator or browser rendering engine was available here. Native playback, actual device voices and a full TypeScript typecheck still need verification in your project. The MP4 is a render of the shared tracks, not a recording from Expo.

## Optional tools

You do not need these to run the Expo component. To rebuild the standalone preview or reproduce the checks, install `sharp` and `playwright@1.62.1` in the kit directory:

```sh
npm install --no-save sharp playwright@1.62.1
node tools/build-preview.cjs
node tools/verify.cjs
```

With `ffmpeg` on your PATH, regenerate the video and storyboard:

```sh
node tools/render-test.cjs
```

To re-export the existing atlas and editable mouth sources:

```sh
node tools/export-assets.cjs
node tools/build-preview.cjs
```

## Official documentation

- [Expo project templates](https://docs.expo.dev/more/create-expo/)
- [Expo Speech: installation, callbacks and iOS silent mode](https://docs.expo.dev/versions/latest/sdk/speech/)
- [React Native Animated](https://reactnative.dev/docs/animated)
- [React Native accessibility preferences](https://reactnative.dev/docs/accessibilityinfo)
