import React, { useEffect, useRef } from 'react';
import { Animated, Easing, Image, StyleSheet } from 'react-native';
import { CANVAS, LAYOUT } from './layout';
import { Keyframe, Mode, TRACKS } from './motion';

const sprites = {
  body: require('../assets/body.png'),
  head: require('../assets/head.png'),
  armRest: require('../assets/arm-rest.png'),
  armWave: require('../assets/arm-wave.png'),
  mouthClosed: require('../assets/mouth-closed.png'),
  mouthOpen: require('../assets/mouth-open.png'),
};

function animateTrack(value: Animated.Value, track: Keyframe[]) {
  return Animated.sequence(track.slice(1).map((frame, index) => Animated.timing(value, {
    toValue: frame.value,
    duration: frame.time - track[index].time,
    easing: Easing.inOut(Easing.sin),
    useNativeDriver: true,
    isInteraction: false,
  })));
}

type Props = {
  width?: number;
  mode?: Mode;
  speaking?: boolean;
  gestureId?: number;
  active?: boolean;
  reducedMotion?: boolean;
};

export function OddiesCharacter({ width = 320, mode = 'idle', speaking = false, gestureId = 0, active = true, reducedMotion = false }: Props) {
  const scale = width / CANVAS.width;
  const height = CANVAS.height * scale;
  const breath = useRef(new Animated.Value(1)).current;
  const head = useRef(new Animated.Value(0)).current;
  const mouth = useRef(new Animated.Value(0)).current;
  const wave = useRef(new Animated.Value(0)).current;
  const waveOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    breath.setValue(1);
    head.setValue(0);
    if (!active || reducedMotion) return;
    const loop = Animated.loop(Animated.parallel([
      animateTrack(breath, TRACKS.breath), animateTrack(head, TRACKS.head),
    ]));
    loop.start();
    return () => { loop.stop(); breath.setValue(1); head.setValue(0); };
  }, [active, reducedMotion, breath, head]);

  useEffect(() => {
    mouth.setValue(0);
    if (!active || !speaking) return;
    const loop = Animated.loop(animateTrack(mouth, TRACKS.mouth));
    loop.start();
    return () => { loop.stop(); mouth.setValue(0); };
  }, [active, speaking, mouth]);

  useEffect(() => {
    wave.setValue(0);
    waveOpacity.setValue(0);
    if (!active || mode !== 'hello') return;
    const animation = reducedMotion
      ? animateTrack(waveOpacity, TRACKS.waveOpacity)
      : Animated.parallel([animateTrack(wave, TRACKS.wave), animateTrack(waveOpacity, TRACKS.waveOpacity)]);
    animation.start();
    return () => { animation.stop(); wave.setValue(0); waveOpacity.setValue(0); };
  }, [active, mode, gestureId, reducedMotion, wave, waveOpacity]);

  const box = (p: { x: number; y: number; width: number; height: number }) => ({
    position: 'absolute' as const, left: p.x * scale, top: p.y * scale,
    width: p.width * scale, height: p.height * scale,
  });
  // Full-canvas wrappers have their default origin at the center. Translate to
  // the chosen joint, rotate/scale, then translate back to keep that joint fixed.
  const offset = (p: { x: number; y: number }) => ({ x: (p.x - CANVAS.width / 2) * scale, y: (p.y - CANVAS.height / 2) * scale });
  const feet = offset(LAYOUT.feetPivot);
  const neck = offset(LAYOUT.headPivot);
  const shoulder = offset(LAYOUT.armPivot);
  const headDegrees = head.interpolate({ inputRange: [-1, 1], outputRange: ['-1deg', '1deg'] });
  const armDegrees = wave.interpolate({ inputRange: [-10, 10], outputRange: ['-10deg', '10deg'] });
  const closedOpacity = mouth.interpolate({ inputRange: [0, 1], outputRange: [1, 0] });
  const restOpacity = waveOpacity.interpolate({ inputRange: [0, 1], outputRange: [1, 0] });
  const mouthScale = mouth.interpolate({ inputRange: [0, 1], outputRange: [0.15, 1] });

  return (
    <Animated.View style={{ width, height }} accessible accessibilityLabel="Oddie character" pointerEvents="none">
      <Animated.View style={[StyleSheet.absoluteFillObject, { transform: [
        { translateY: feet.y }, { scaleY: breath }, { translateY: -feet.y },
      ] }]}>
        <Image source={sprites.body} style={box(LAYOUT.body)} resizeMode="stretch" />
        <Animated.Image source={sprites.armRest} style={[box(LAYOUT.armRest), { opacity: restOpacity }]} resizeMode="stretch" />
        <Animated.View style={[StyleSheet.absoluteFillObject, { opacity: waveOpacity, transform: [
          { translateX: shoulder.x }, { translateY: shoulder.y }, { rotate: armDegrees },
          { translateX: -shoulder.x }, { translateY: -shoulder.y },
        ] }]}>
          <Image source={sprites.armWave} style={box(LAYOUT.armWave)} resizeMode="stretch" />
        </Animated.View>
        <Animated.View style={[StyleSheet.absoluteFillObject, { transform: [
          { translateX: neck.x }, { translateY: neck.y }, { rotate: headDegrees },
          { translateX: -neck.x }, { translateY: -neck.y },
        ] }]}>
          <Image source={sprites.head} style={box(LAYOUT.head)} resizeMode="stretch" />
          <Animated.Image source={sprites.mouthClosed} style={[box(LAYOUT.mouthClosed), { opacity: closedOpacity }]} resizeMode="stretch" />
          <Animated.Image source={sprites.mouthOpen} style={[box(LAYOUT.mouthOpen), {
            opacity: mouth, transform: [{ scaleY: mouthScale }],
          }]} resizeMode="stretch" />
        </Animated.View>
      </Animated.View>
    </Animated.View>
  );
}
