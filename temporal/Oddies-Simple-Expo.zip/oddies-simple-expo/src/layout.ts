// Coordinates refer to one 600 × 1010 character canvas. Every animated wrapper
// uses this canvas too, so head/arm pivots remain stable at any display size.
export const CANVAS = { width: 600, height: 1010 } as const;
export const LAYOUT = {
  body: { x: 144, y: 245, width: 310, height: 728 },
  head: { x: 143, y: 28, width: 320.54, height: 421.6 },
  armRest: { x: 327, y: 265, width: 131.04, height: 351.96 },
  armWave: { x: 341, y: 190, width: 242.76, height: 294.84 },
  mouthClosed: { x: 282, y: 201, width: 36, height: 18 },
  mouthOpen: { x: 282, y: 199, width: 36, height: 22.5 },
  headPivot: { x: 300, y: 252 },
  armPivot: { x: 378, y: 313 },
  feetPivot: { x: 300, y: 973 },
} as const;
