// All times are milliseconds. These tracks also drive the downloadable preview.
export type Mode = 'idle' | 'talking' | 'hello';
export type Keyframe = { time: number; value: number };
export const HELLO_DURATION = 2360;
export const TRACKS: Record<string, Keyframe[]> = {
  breath: [{ time: 0, value: 1 }, { time: 1800, value: 1.003 }, { time: 3600, value: 1 }],
  head: [{ time: 0, value: 0 }, { time: 1800, value: -0.65 }, { time: 3600, value: 0 }],
  mouth: [
    { time: 0, value: 0 }, { time: 90, value: 0.8 },
    { time: 200, value: 0.25 }, { time: 260, value: 0 },
    { time: 390, value: 1 }, { time: 490, value: 0.35 },
    { time: 560, value: 0 }, { time: 650, value: 0.7 },
    { time: 760, value: 0.2 }, { time: 830, value: 0 },
  ],
  wave: [
    { time: 0, value: 0 }, { time: 240, value: 0 },
    { time: 540, value: -7 }, { time: 820, value: 6 },
    { time: 1100, value: -6 }, { time: 1380, value: 5 },
    { time: 1720, value: -3 }, { time: 1980, value: 0 },
    { time: HELLO_DURATION, value: 0 },
  ],
  waveOpacity: [
    { time: 0, value: 0 }, { time: 120, value: 1 },
    { time: 2180, value: 1 }, { time: HELLO_DURATION, value: 0 },
  ],
};

// Same sine easing as Easing.inOut(Easing.sin) in React Native.
export function sampleTrack(track: Keyframe[], time: number, loop = false): number {
  const end = track[track.length - 1].time;
  const t = loop ? Math.max(0, time) % end : Math.min(end, Math.max(0, time));
  for (let i = 1; i < track.length; i++) {
    if (t <= track[i].time) {
      const a = track[i - 1];
      const b = track[i];
      const progress = (t - a.time) / (b.time - a.time);
      const ease = (1 - Math.cos(Math.PI * progress)) / 2;
      return a.value + (b.value - a.value) * ease;
    }
  }
  return track[track.length - 1].value;
}

export function sampleMotion(mode: Mode, elapsed: number, speaking = false, reducedMotion = false, active = true, speechElapsed = elapsed) {
  return {
    breath: active && !reducedMotion ? sampleTrack(TRACKS.breath, elapsed, true) : 1,
    head: active && !reducedMotion ? sampleTrack(TRACKS.head, elapsed, true) : 0,
    wave: active && mode === 'hello' && !reducedMotion ? sampleTrack(TRACKS.wave, elapsed) : 0,
    waveOpacity: active && mode === 'hello' ? sampleTrack(TRACKS.waveOpacity, elapsed) : 0,
    mouth: active && speaking ? sampleTrack(TRACKS.mouth, speechElapsed, true) : 0,
  };
}
