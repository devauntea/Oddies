// Extract the requested character parts from the ImageGen atlas; artwork pixels
// are preserved. Mouth overlays are small code-native graphics for this demo.
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');
const root = path.resolve(__dirname, '..');
const atlas = process.argv[2] || path.join(root, 'assets/atlas.png');
const crops = {
  body: [225, 33, 310, 728],
  head: [647, 80, 517, 680],
  'arm-rest': [274, 798, 156, 419],
  'arm-wave': [773, 814, 289, 351],
};
const closed = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 64"><defs><linearGradient id="lip" x2="0" y2="1"><stop stop-color="#ED977D"/><stop offset="1" stop-color="#D97667"/></linearGradient></defs><path d="M12 22 C40 29 80 29 116 17 C106 38 38 48 12 22Z" fill="url(#lip)" opacity=".8"/><path d="M12 22 Q64 35 116 17" fill="none" stroke="#CB7665" stroke-width="5" stroke-linecap="round"/><path d="M40 35 Q63 42 87 33" fill="none" stroke="#F2A18A" stroke-width="3" opacity=".55"/></svg>`;
const open = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 80"><defs><linearGradient id="mouth" x2="0" y2="1"><stop stop-color="#512E32"/><stop offset="1" stop-color="#873E42"/></linearGradient><linearGradient id="rim" x2="0" y2="1"><stop stop-color="#EC977E"/><stop offset="1" stop-color="#CC7667"/></linearGradient></defs><path d="M13 24 Q63 14 115 22 C111 68 28 77 13 24Z" fill="url(#mouth)" stroke="url(#rim)" stroke-width="5"/><path d="M31 27 Q65 26 97 25 L95 32 Q65 36 34 33Z" fill="#F8EAD6" opacity=".9"/><path d="M40 58 Q65 43 91 55 Q69 68 40 58Z" fill="#D27C78" opacity=".8"/></svg>`;
(async () => {
  fs.mkdirSync(path.join(root, 'assets'), { recursive: true });
  if (path.resolve(atlas) !== path.join(root,'assets/atlas.png')) fs.copyFileSync(atlas, path.join(root, 'assets/atlas.png'));
  for (const [name, [left, top, width, height]] of Object.entries(crops)) {
    // The atlas's resting arm faced the wrong way. Keep the corrected source
    // independent so re-exporting the atlas cannot reintroduce that mistake.
    if (name === 'arm-rest' && fs.existsSync(path.join(root, 'assets/arm-rest-source.png'))) {
      await sharp(path.join(root, 'assets/arm-rest-source.png')).trim({ threshold: 0 })
        .resize({ width, height, fit: 'contain', background: { r: 0, g: 0, b: 0, alpha: 0 } })
        .png().toFile(path.join(root, 'assets/arm-rest.png'));
      continue;
    }
    await sharp(atlas).extract({left, top, width, height}).png().toFile(path.join(root, `assets/${name}.png`));
  }
  for (const [name, source] of [['mouth-closed',closed],['mouth-open',open]]) {
    fs.writeFileSync(path.join(root,`assets/${name}.svg`),source);
    await sharp(Buffer.from(source)).resize(384, name === 'mouth-closed' ? 192 : 240).png().toFile(path.join(root,`assets/${name}.png`));
  }
  console.log('Exported 4 character PNG layers and 2 mouth overlays.');
})();
