// Optional preview tooling. Expo uses Metro directly and does not need this.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const playwrightRoot = path.dirname(require.resolve('playwright/package.json'));
const { babelTransform } = require(path.join(playwrightRoot, 'lib/transform/babelBundle.js'));
function compile(filename) {
  return babelTransform(fs.readFileSync(filename, 'utf8'), filename, false, [], []).code
    .replace(/^\/\/# sourceMappingURL=.*$/gm, '');
}
function load(filename) {
  const module = { exports: {} };
  vm.runInNewContext(compile(filename), { module, exports: module.exports, require });
  return module.exports;
}
module.exports = { compile, load };
