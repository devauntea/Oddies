// Render the same artwork and motion tracks to a silent MP4/storyboard.
// Requires the optional developer tools: sharp, playwright, and ffmpeg.
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawnSync } = require('child_process');
const sharp = require('sharp');
const { load } = require('./load-source.cjs');
const root = path.resolve(__dirname, '..');
const { LAYOUT } = load(path.join(root,'src/layout.ts'));
const { sampleMotion } = load(path.join(root,'src/motion.ts'));
const sources = Object.fromEntries(['body','head','arm-rest','arm-wave','mouth-closed','mouth-open'].map(name=>[name,'data:image/png;base64,'+fs.readFileSync(path.join(root,`assets/${name}.png`)).toString('base64')]));
const image = (name, p, extra='') => `<image href="${sources[name]}" x="${p.x}" y="${p.y}" width="${p.width}" height="${p.height}" ${extra}/>`;
function character(m) {
  const mouth = LAYOUT.mouthOpen;
  const mx = mouth.x+mouth.width/2, my = mouth.y+mouth.height/2;
  return `<g transform="translate(0 ${LAYOUT.feetPivot.y}) scale(1 ${m.breath}) translate(0 ${-LAYOUT.feetPivot.y})">
    ${image('body',LAYOUT.body)}
    ${image('arm-rest',LAYOUT.armRest,`opacity="${1-m.waveOpacity}"`)}
    <g opacity="${m.waveOpacity}" transform="rotate(${m.wave} ${LAYOUT.armPivot.x} ${LAYOUT.armPivot.y})">${image('arm-wave',LAYOUT.armWave)}</g>
    <g transform="rotate(${m.head} ${LAYOUT.headPivot.x} ${LAYOUT.headPivot.y})">
      ${image('head',LAYOUT.head)}${image('mouth-closed',LAYOUT.mouthClosed,`opacity="${1-m.mouth}"`)}
      <g opacity="${m.mouth}" transform="translate(${mx} ${my}) scale(1 ${.15+.85*m.mouth}) translate(${-mx} ${-my})">${image('mouth-open',mouth)}</g>
    </g>
  </g>`;
}
const descriptions = {idle:'Gentle breathing · small head tilt',talking:'Two mouth shapes · simple speech rhythm',hello:'One short wave · return to idle'};
function frameSvg(mode, elapsed, speaking=true) {
  const m=sampleMotion(mode,elapsed,mode==='talking'||(mode==='hello'&&elapsed<1750));
  return `<svg xmlns="http://www.w3.org/2000/svg" width="720" height="1240" viewBox="0 0 720 1240">
  <rect width="720" height="1240" fill="#F7F4EE"/>
  <text x="48" y="48" font-family="sans-serif" font-size="13" letter-spacing="2" fill="#817967">ODDIES · SIMPLE ANIMATION TEST</text>
  <text x="48" y="95" font-family="sans-serif" font-size="35" font-weight="600" fill="#302B40">${mode==='idle'?'Idle':mode==='talking'?'Talking':'Say hello'}</text>
  <g transform="translate(60 125)">${character(m)}</g>
  <text x="360" y="1160" font-family="sans-serif" font-size="15" text-anchor="middle" fill="#74687D">${descriptions[mode]}</text>
  <text x="360" y="1196" font-family="sans-serif" font-size="12" text-anchor="middle" fill="#958B9E">Silent visual test · device voice is available in the app</text>
  </svg>`;
}
async function main(){
  const out=path.join(root,'test');fs.mkdirSync(out,{recursive:true});
  const shots=[['idle',1800],['talking',390],['hello',820]];
  const panels=await Promise.all(shots.map(async([mode,time],index)=>({input:await sharp(Buffer.from(frameSvg(mode,time))).resize(360,620).png().toBuffer(),left:360*index,top:0})));
  await sharp({create:{width:1080,height:620,channels:4,background:'#F7F4EE'}}).composite(panels).png().toFile(path.join(out,'storyboard.png'));
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'oddies-motion-'));
  const fps=24;let index=0;
  try{
    for(const [mode,duration] of [['idle',3600],['talking',4000],['hello',3000]]){
      const count=Math.round(duration/1000*fps);
      for(let i=0;i<count;i++){
        await sharp(Buffer.from(frameSvg(mode,i/fps*1000))).png().toFile(path.join(temp,`${String(index++).padStart(5,'0')}.png`));
      }
    }
    const ffmpeg=spawnSync('ffmpeg',['-y','-loglevel','error','-framerate',String(fps),'-i',path.join(temp,'%05d.png'),'-c:v','libx264','-preset','fast','-crf','21','-pix_fmt','yuv420p','-movflags','+faststart',path.join(out,'animation-test.mp4')],{encoding:'utf8'});
    if(ffmpeg.status!==0)throw new Error(ffmpeg.stderr||'ffmpeg failed');
  }finally{fs.rmSync(temp,{recursive:true,force:true});}
  console.log(`Rendered ${index} frames to test/animation-test.mp4 and test/storyboard.png`);
}
main().catch(error=>{console.error(error);process.exitCode=1;});
