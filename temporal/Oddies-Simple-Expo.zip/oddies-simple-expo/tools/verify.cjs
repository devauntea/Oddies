const assert = require('assert/strict');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const sharp = require('sharp');
const { compile, load } = require('./load-source.cjs');
const root = path.resolve(__dirname, '..');
const { sampleMotion, TRACKS, HELLO_DURATION } = load(path.join(root,'src/motion.ts'));
const { LAYOUT } = load(path.join(root,'src/layout.ts'));
const checks=[];
function checked(label, fn){fn();checks.push(label);}
function clock(){
 let now=0,id=0;const timers=new Map();
 return { now:()=>now, setTimeout:(fn,delay)=>{timers.set(++id,{fn,time:now+delay});return id;},clearTimeout:id=>timers.delete(id),advance(ms){
  const target=now+ms;
  for(;;){const pending=[...timers.entries()].filter(([,v])=>v.time<=target).sort((a,b)=>a[1].time-b[1].time)[0];if(!pending)break;now=pending[1].time;timers.delete(pending[0]);pending[1].fn();}
  now=target;
 }};
}
function browser(){
 const c=clock(),elements=new Map(),docEvents={},windowEvents={};let raf,utterance;
 const element=id=>{if(!elements.has(id))elements.set(id,{style:{},checked:false,attributes:{},events:{},textContent:'',setAttribute(k,v){this.attributes[k]=v;},addEventListener(k,v){this.events[k]=v;}});return elements.get(id);};
 const document={getElementById:element,hidden:false,addEventListener:(k,v)=>docEvents[k]=v};
 const window={matchMedia:()=>({matches:false,addEventListener(){}}),addEventListener:(k,v)=>windowEvents[k]=v,speechSynthesis:{cancel(){},speak(u){utterance=u;}},SpeechSynthesisUtterance:function(text){this.text=text;}};
 const context={document,window,performance:{now:c.now},setTimeout:c.setTimeout,clearTimeout:c.clearTimeout,requestAnimationFrame:fn=>raf=fn,SpeechSynthesisUtterance:window.SpeechSynthesisUtterance};
 const script=fs.readFileSync(path.join(root,'preview.html'),'utf8').match(/<script>([\s\S]*?)<\/script>/)[1];
 vm.runInNewContext(script,context);
 return {element,document,docEvents,click:id=>element(id).events.click(),advance:ms=>{c.advance(ms);raf(c.now());},frame:()=>raf(c.now()),utterance:()=>utterance};
}
function nativeApp(){
 const c=clock(),hooks=[];let index=0,pending=[],tree,appStateHandler,reduceHandler,utterance,unmount;
 const same=(a,b)=>a&&b&&a.length===b.length&&a.every((v,i)=>v===b[i]);
 const react={__esModule:true,useState(initial){const i=index++;if(!(i in hooks))hooks[i]=initial;return [hooks[i],value=>hooks[i]=typeof value==='function'?value(hooks[i]):value];},useRef(initial){const i=index++;if(!(i in hooks))hooks[i]={current:initial};return hooks[i];},useCallback(fn,deps){const i=index++;if(!hooks[i]||!same(hooks[i].deps,deps))hooks[i]={fn,deps};return hooks[i].fn;},useEffect(fn,deps){const i=index++;if(!hooks[i]||!same(hooks[i].deps,deps)){hooks[i]={deps};pending.push(fn);}}};
 const jsx=(type,props)=>({type,props});
 const native={AccessibilityInfo:{isReduceMotionEnabled:()=>Promise.resolve(false),addEventListener:(name,fn)=>{reduceHandler=fn;return {remove(){}};}},AppState:{currentState:'active',addEventListener:(name,fn)=>{appStateHandler=fn;return {remove(){}};}},StyleSheet:{create:v=>v},useWindowDimensions:()=>({width:390})};
 for(const name of ['Pressable','SafeAreaView','ScrollView','Switch','Text','View'])native[name]=name;
 const motion=load(path.join(root,'src/motion.ts'));
 const speech={__esModule:true,stop:()=>Promise.resolve(),speak:(text,options)=>utterance={text,...options}};
 const module={exports:{}};
 const requireMock=name=>{
  if(name==='react')return react;if(name==='react/jsx-runtime')return {jsx,jsxs:jsx};
  if(name==='react-native')return native;if(name==='expo-speech')return speech;
  if(name==='./src/motion')return motion;if(name==='./src/OddiesCharacter')return {OddiesCharacter:'Character'};
  throw new Error('Unexpected import: '+name);
 };
 vm.runInNewContext(compile(path.join(root,'App.tsx')),{module,exports:module.exports,require:requireMock,setTimeout:c.setTimeout,clearTimeout:c.clearTimeout});
 function render(){index=0;tree=module.exports.default();for(const effect of pending.splice(0))unmount=effect();return tree;}
 function all(node){if(!node)return [];if(Array.isArray(node))return node.flatMap(all);if(typeof node!=='object')return [];return [node,...all(node.props?.children)];}
 const find=type=>all(render()).find(n=>n.type===type);
 render();
 return {render,character:()=>find('Character').props,button:i=>all(render()).filter(n=>n.type==='Pressable')[i],voice:()=>find('Switch').props,advance:ms=>{c.advance(ms);render();},utterance:()=>utterance,background:()=>appStateHandler('background'),reduce:()=>reduceHandler(true),unmount:()=>unmount()};
}
const flush=async()=>{await Promise.resolve();await Promise.resolve();};
async function main(){
 checked('All TypeScript/TSX files parse and transpile',()=>{
  for(const file of ['App.tsx','src/OddiesCharacter.tsx','src/motion.ts','src/layout.ts'])assert.ok(compile(path.join(root,file)).length>100);
 });
 checked('Mouth closes when speech ends or the app is inactive',()=>{
  assert.equal(sampleMotion('talking',390,true).mouth,1);
  assert.equal(sampleMotion('talking',390,false).mouth,0);
  assert.equal(sampleMotion('talking',390,true,false,false).mouth,0);
 });
 checked('Hello finishes once and returns both arm tracks to rest',()=>{
  assert.equal(sampleMotion('hello',820).wave,6);
  for(const t of [HELLO_DURATION,3000,10000]){assert.equal(sampleMotion('hello',t).wave,0);assert.equal(sampleMotion('hello',t).waveOpacity,0);}
 });
 checked('Reduced motion disables breathing, head tilt and arm rotation',()=>{
  const m=sampleMotion('hello',820,true,true);assert.equal(m.breath,1);assert.equal(m.head,0);assert.equal(m.wave,0);assert.equal(m.waveOpacity,1);
 });
 checked('Feet stay at their pivot during breathing; tracks remain bounded',()=>{
  const y=LAYOUT.feetPivot.y,s=1.003;assert.equal(y*s+y*(1-s),y);
  for(let t=0;t<=12000;t+=25){const m=sampleMotion('hello',t,true);assert.ok(m.breath>=1&&m.breath<=1.003);assert.ok(m.mouth>=0&&m.mouth<=1);assert.ok(m.waveOpacity>=0&&m.waveOpacity<=1);}
 });
 for(const name of ['body','head','arm-rest','arm-wave','mouth-closed','mouth-open']){
  const image=sharp(path.join(root,`assets/${name}.png`));const {data,info}=await image.raw().toBuffer({resolveWithObject:true});
  assert.equal(info.channels,4);let clear=false,visible=false;for(let i=3;i<data.length;i+=4){if(data[i]===0)clear=true;if(data[i]===255)visible=true;}
  assert.ok(clear&&visible,`${name}: transparent background and visible pixels`);
 }checks.push('All six delivered PNGs have real alpha transparency');
 checked('Browser silent hello closes its mouth and returns to idle',()=>{
  const b=browser();b.click('hello');b.advance(390);assert.equal(b.element('mouthOpen').style.opacity,1);
  b.advance(1360);assert.equal(b.element('mouthOpen').style.opacity,0);
  b.advance(610);assert.equal(b.element('idle').attributes['aria-pressed'],'true');assert.equal(b.element('wave').style.opacity,0);
 });
 checked('Browser speech callbacks and stale requests are handled',()=>{
  const b=browser();b.element('voice').checked=true;b.click('talking');const old=b.utterance();b.frame();assert.equal(b.element('mouthOpen').style.opacity,0);
  old.onstart();b.advance(390);assert.equal(b.element('mouthOpen').style.opacity,1);
  b.click('hello');b.utterance().onstart();old.onend();b.advance(390);assert.equal(b.element('mouthOpen').style.opacity,1);
  b.utterance().onend();b.frame();assert.equal(b.element('mouthOpen').style.opacity,0);
  b.document.hidden=true;b.docEvents.visibilitychange();b.frame();assert.equal(b.element('idle').attributes['aria-pressed'],'true');
 });
 const app=nativeApp();await flush();
 app.button(1).props.onPress();await flush();assert.equal(app.character().speaking,false);
 const old=app.utterance();old.onStart();assert.equal(app.character().speaking,true);
 app.button(2).props.onPress();await flush();app.utterance().onStart();old.onDone();assert.equal(app.character().mode,'hello');assert.equal(app.character().speaking,true);
 app.utterance().onDone();assert.equal(app.character().speaking,false);assert.equal(app.character().mode,'hello');
 app.advance(HELLO_DURATION);assert.equal(app.character().mode,'idle');
 app.voice().onValueChange(false);app.button(1).props.onPress();await flush();assert.equal(app.character().speaking,true);
 app.background();assert.equal(app.character().speaking,false);assert.equal(app.character().active,false);app.unmount();
 checks.push('Actual App.tsx speech start/stop, stale callbacks, hello completion and background logic pass with mocked native APIs');
 fs.mkdirSync(path.join(root,'test'),{recursive:true});
 fs.writeFileSync(path.join(root,'test/verification.json'),JSON.stringify({passed:checks,limits:['Native APIs were mocked. No Expo device/emulator or browser rendering engine was available.','This is syntax/transpilation validation, not a full TypeScript typecheck.','MP4 is a silent render of shared motion tracks, not a device screen recording.']},null,2)+'\n');
 console.log(checks.map(s=>'PASS · '+s).join('\n'));
}
main().catch(error=>{console.error(error);process.exitCode=1;});
